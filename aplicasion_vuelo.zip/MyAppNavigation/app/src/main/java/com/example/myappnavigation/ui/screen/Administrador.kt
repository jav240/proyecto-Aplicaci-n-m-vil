package com.example.myappnavigation.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myappnavigation.ui.components.Footer
import com.example.myappnavigation.ui.components.Header

@Composable
fun Administrador(onNavigateToReporte: () -> Unit) {
    Scaffold(
        topBar = { Header("ADMINISTRADOR") },
        bottomBar = { Footer() }
    ) {
        innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Bloques de vuelo", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("(datos ficticios de ejemplo)", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Bloque 1: 10:00-11:00 · Tobalaba · 2 inscritos", style = MaterialTheme.typography.bodyLarge)
            Text("Bloque 2: 11:00-12:00 · Tobalaba · 2 inscritos", style = MaterialTheme.typography.bodyLarge)
            Text("Bloque 3: 10:00-11:00 · Talcahuano · 0 inscritos", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = { onNavigateToReporte() }) {
                Text(text = "Ver reporte para Bienestar")
            }
        }
    }
}
