package com.example.myappnavigation.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myappnavigation.ui.screen.Administrador
import com.example.myappnavigation.ui.screen.Embarque
import com.example.myappnavigation.ui.screen.Login
import com.example.myappnavigation.ui.screen.Operador
import com.example.myappnavigation.ui.screen.Register
import com.example.myappnavigation.ui.screen.Reporte
import com.example.myappnavigation.ui.screen.ScreenHeroe
import com.example.myappnavigation.ui.screen.Vuelo

object Routes{
    const val SUPERHERO = "superhero"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val ADMIN = "admin"
    const val OPERADOR = "operador"
    const val EMBARQUE = "embarque"
    const val VUELO = "vuelo"
    const val REPORTE = "reporte"
}

@Composable
fun AppNavigation(){
    val navController = rememberNavController()
    NavHost(
        navController=navController,
        startDestination = Routes.SUPERHERO     //definimos el inicio
    ){
        composable (Routes.SUPERHERO) {
            ScreenHeroe (
                onNavigateToLogin = {
                    navController.navigate(Routes.LOGIN)
                }
            )
        }//composable inicial

        composable (Routes.LOGIN) {
            Login (
                onNavigateToRegister = {
                    navController.navigate(Routes.REGISTER)
                },
                onNavigateToAdmin = {
                    navController.navigate(Routes.ADMIN)
                },
                onNavigateToOperador = {
                    navController.navigate(Routes.OPERADOR)
                }
            )
        }

        composable (Routes.REGISTER){
            Register()
        }

        composable (Routes.ADMIN) {
            Administrador (
                onNavigateToReporte = {
                    navController.navigate(Routes.REPORTE)
                }
            )
        }

        composable (Routes.OPERADOR) {
            Operador (
                onNavigateToEmbarque = {
                    navController.navigate(Routes.EMBARQUE)
                },
                onNavigateToVuelo = {
                    navController.navigate(Routes.VUELO)
                }
            )
        }

        composable (Routes.EMBARQUE) {
            Embarque()
        }

        composable (Routes.VUELO) {
            Vuelo()
        }

        composable (Routes.REPORTE) {
            Reporte()
        }
    }
}
