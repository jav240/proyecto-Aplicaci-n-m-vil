package com.example.myappnavigation.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.myappnavigation.ui.components.Footer
import com.example.myappnavigation.ui.components.Header

@Composable
fun Embarque() {
    val context = LocalContext.current
    Scaffold(
        topBar = { Header("EMBARQUE") },
        bottomBar = { Footer() }
    ) {
        innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Datos del invitado", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Nombre: Invitado Ficticio Uno", style = MaterialTheme.typography.bodyLarge)
            Text("RUT: 11.111.111-1", style = MaterialTheme.typography.bodyLarge)
            Text("Categoría: Socio Club", style = MaterialTheme.typography.bodyLarge)
            Text("Peso verificado: 78 kg (ejemplo)", style = MaterialTheme.typography.bodyLarge)
            Text("Consentimiento: PENDIENTE", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = {
                Toast.makeText(context, "Embarque guardado (demo)", Toast.LENGTH_SHORT).show()
            }) {
                Text(text = "Guardar embarque")
            }
        }
    }
}
