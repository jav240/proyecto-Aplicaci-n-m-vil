package com.example.myappnavigation.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myappnavigation.ui.components.Footer
import com.example.myappnavigation.ui.components.Header

@Composable
fun Reporte() {
    Scaffold(
        topBar = { Header("REPORTE PARA BIENESTAR") },
        bottomBar = { Footer() }
    ) {
        innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Resumen de la jornada", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("(datos ficticios de ejemplo)", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Personas beneficiadas: 4", style = MaterialTheme.typography.bodyLarge)
            Text("Pilotos participantes: 2", style = MaterialTheme.typography.bodyLarge)
            Text("Aeronaves empleadas: 2", style = MaterialTheme.typography.bodyLarge)
            Text("Horas de vuelo consumidas: 3.0", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
