package com.example.myappnavigation.ui.screen

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.myappnavigation.ui.components.Footer
import com.example.myappnavigation.ui.components.Header

@Composable
fun Vuelo() {
    val context = LocalContext.current
    Scaffold(
        topBar = { Header("REGISTRO DE VUELO") },
        bottomBar = { Footer() }
    ) {
        innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Datos del vuelo", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Aeronave: CC-AAA · Cessna 172 (ficticia)", style = MaterialTheme.typography.bodyLarge)
            Text("Piloto al mando: Piloto Ficticio Uno", style = MaterialTheme.typography.bodyLarge)
            Text("Tripulantes: 3", style = MaterialTheme.typography.bodyLarge)
            Text("Horómetro inicial: 1200.0", style = MaterialTheme.typography.bodyLarge)
            Text("Horómetro final: 1201.5", style = MaterialTheme.typography.bodyLarge)
            Text("Horas consumidas: 1.5", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = {
                Toast.makeText(context, "Vuelo guardado (demo)", Toast.LENGTH_SHORT).show()
            }) {
                Text(text = "Guardar vuelo")
            }
        }
    }
}
