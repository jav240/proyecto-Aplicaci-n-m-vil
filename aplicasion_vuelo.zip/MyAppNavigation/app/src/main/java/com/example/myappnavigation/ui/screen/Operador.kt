package com.example.myappnavigation.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myappnavigation.ui.components.Footer
import com.example.myappnavigation.ui.components.Header

@Composable
fun Operador(onNavigateToEmbarque: () -> Unit, onNavigateToVuelo: () -> Unit) {
    Scaffold(
        topBar = { Header("CONTROL EN LOSA") },
        bottomBar = { Footer() }
    ) {
        innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Invitados del bloque", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))
            Text("Invitado Ficticio Uno · Socio Club", style = MaterialTheme.typography.bodyLarge)
            Text("Invitado Ficticio Dos · Socio Bienestar", style = MaterialTheme.typography.bodyLarge)
            Text("Invitado Ficticio Tres · Socio Bienestar", style = MaterialTheme.typography.bodyLarge)
            Spacer(modifier = Modifier.height(24.dp))
            Button(onClick = { onNavigateToEmbarque() }) {
                Text(text = "Registrar embarque")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { onNavigateToVuelo() }) {
                Text(text = "Registrar vuelo")
            }
        }
    }
}
